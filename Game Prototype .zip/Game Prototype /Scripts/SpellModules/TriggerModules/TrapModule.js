//places a mark on the target location, if a target comes close the spell will be casted from that location
class TrapModule extends Module
{
  static displayName = 'Trap'
  static description = ['The trap module is not yet implemented']
  //applys to caster when equipped
  
}

console.log(TrapModule.name+' loaded...')