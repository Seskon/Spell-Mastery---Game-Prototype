class TargetMarker extends GameObject
{
  constructor(spellEntity, targetPosition)
  {
    super(targetPosition.x, targetPosition.y)
    
    this.spellEntity = spellEntity
    
    //this.addComponent(new SpriteComponent('TargetMarker'))
    
  }
  
  setupComplete()
  {
    this.area = this.spellEntity.attributeSheet.getAttribute('area')
    this.area = this.area.baseValue
    
    this.addComponent(new ClickComponent(4, new Vector2(this.area), () => {
        spellEntity.destroy()
        this.destroy()
      }
    ))
    
    this.addComponent(new CircleRenderComponent())
  }
}

console.log(TargetMarker.name+' loaded...')