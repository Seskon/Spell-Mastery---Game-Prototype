//places a marker on the ground if no markers are already placed. if cast again the spell will be casted at target location
class MineModule extends Module
{
  static displayName = 'Mine'

  static description = ['The mine module is not yet implemented']
  //applys to caster when equipped
  
}

console.log(MineModule.name+' loaded...')