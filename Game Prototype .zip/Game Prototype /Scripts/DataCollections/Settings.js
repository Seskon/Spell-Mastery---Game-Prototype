class Settings
{
  static showDimensions = false
  static showAnchor = false
  static showProgressBars = true
  static showInput = false
  static drawCollider = true
  static showRange = true
}