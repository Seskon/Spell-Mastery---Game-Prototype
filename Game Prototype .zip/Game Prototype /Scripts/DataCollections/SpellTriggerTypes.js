class SpellTriggerTypes
{
  static onCrit = 'onCrit'
  static onCast = 'onCast'
  static onDamageTaken = 'onDamagTaken'
  static onDeath = 'onDeath'
  static onHit = 'onHit'
  static onKill = 'onKill'
  static mine = 'mine'
  static trap = 'trap'
}

console.log(SpellTriggerTypes.name+' loaded...')